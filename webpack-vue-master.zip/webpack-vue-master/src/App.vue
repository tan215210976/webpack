<template>
  <div class="app">
    app component
    <img
      src="./assets/images/1.png"
      alt=""
    >
  </div>
</template>

<script>
export default {
  data: () => ({})
};
</script>

<style  scoped>
</style>



